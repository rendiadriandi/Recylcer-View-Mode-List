package com.rendi.myapps.model;

public class Hero {
    private String heroes_name;
    private String from;
    private String photo;

    public String getHeroes_name() {
        return heroes_name;
    }

    public void setHeroes_name(String heroes_name) {
        this.heroes_name = heroes_name;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
